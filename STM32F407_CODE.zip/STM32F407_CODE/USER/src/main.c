#include <STM32F4xx.h>
#include <stdio.h>
#include "led.h"
#include "key.h"
#include "exti.h"
#include "SisTick.h"
#include "tim.h"
#include "BEEP.h"
#include "SisTick.h"
#include "car.h"
#include "usart.h"


extern uint16_t reav_data;
extern int temp,pre,hum,height,light;
extern unsigned char u3_recv[256]; //保存接收到的数据
extern int u3_recv_count; //记录接收到的字节数				
extern int u3_recv_flag;  //0 - 接收未完成	，1 - 接收完成 
extern int smoke;
extern unsigned char u1_recv[256]; //保存接收到的数据
extern int u1_recv_count ; //记录接收到的字节数				
extern int u1_recv_flag ;  //0 - 接收未完成	，1 - 接收完成 


/*
//烟雾报警器
int main()
{

		USART2_Init();
		USART1_Init(9600);
		USART3_Init();
		uint8_t str2[9]={0xFF,0X01,0X86,0X00,0X00,0X00,0X00,0X00,0X79};
		
		while(1)
		{
			Send_Data_String(USART1,str2,9);
			if(u1_recv_flag == 1)
			{
				printf("smoke=%d	\n",smoke);
		  }
			delay_ms(3000);
		}
}
*/

/*
	MCU发送命令：0xA5+0x83+0x28
*/

//GY_39输出数据到手机+蓝牙控制
int main()
{
  	// 初始化USART1
  	USART1_Init(9600);
	//初始化USART2
	USART2_Init();
	//初始化USART3
	USART3_Init();
	//小车初始化
	CAR_Init(8399,999);
	//蜂鸣器初始化
	BEEP_Init();
	//循迹初始化
	XunJi_Init();
	
	
	//uint8_t str0[] = {"Okay\r\n"};

	//GY_39命令
	uint8_t str1[3] = {0xA5, 0x83,0x28};
	//烟雾报警器命令
	uint8_t str2[9]={0xFF,0X01,0X86,0X00,0X00,0X00,0X00,0X00,0X79};

	
	while(1)
	{	

		//MCU发送给蓝牙，检查是否收到信息
		//Send_Data_String(USART2,str0, sizeof(str0));
		//delay_ms(300);

		
		// 发送命令给GY-39
   		Send_Data_String(USART2,str1, 3);
		//给烟雾报警器发送命令
		Send_Data_String(USART1,str2,9);

    	// 稍作延时，等待GY-39响应
    	delay_ms(3000);

     	// 检查是否有数据从GY-39发送过来
		if( u3_recv_flag == 1)
		{

			//输出temp,pre,hum,height,light
			printf("temp == %d \n",temp);
			printf("pre == %d \n",pre);
			printf("hum == %d \n",hum);
			printf("height == %d \n",height);
			printf("light == %d \n",light);
			printf("--------------------------------------\n");	
			u3_recv_flag = 0;
		}
		

		
		// 检查是否有数据从GY-39发送过来
		if(u1_recv_flag == 1)
		{
			printf("smoke=%d\n",smoke);
			printf("--------------------------------------\n");
			if(smoke > 100)
			{
				BEEP_Ctrl(BEEP_ON);
			}
		}
			
		
		
	}
           
}







/*
//手机蓝牙模块通信
int main()
{
	USART2_Init();
	CAR_Init(8399,400);
	uint8_t str[] = {"HELLO,I am Okay\r\n"};
	delay_ms(500);
	while(1)
	{	
		
		Send_Data_String(USART2, str, sizeof(str));
		delay_ms(500);
		switch (reav_data)
		{
    			case 0x01:
    				//前进
    				set_pwm(200,0,200,0);
    				break;
    			case 0x02:
    				//后退
    				set_pwm(0,200,0,200);
    				break;
    			case 0x03:
    				//左转
    				set_pwm(000,200,200,0);
    				break;
    			case 0x04:
    				//右转
    				set_pwm(200,0,0,200);
    				break;
				case 0x05:
    				//右转
    				set_pwm(0,0,0,0);
    				break;
    			default:
    				//默认停止
    				set_pwm(0,0,0,0);
    				break;
    				
		}
		
	}
}
*/


/*
//测试用printf函数输出到串口
int main()
{	
	USART1_Init(9600);
	int i=0;
	char str[] = {"HELLO,I am Okay\r\n"};

	while(1)
	{
		for(i=0;i<=20;i++)
		{
			delay_ms(2000);
			printf("i == %d\r\n",i);

			delay_ms(2000);
			if(i >= 6 && i <= 8)
			{
				printf("str == %s",str);
			}
		}
		
	}
}
*/

/*
//串口通信
int main()
{
	USART1_Init(Bort);
	CAR_Init(8399,400);
	
	uint8_t str[] = {"HELLO,I am Okay\r\n"};
	delay_ms(3000);
	while(1)
	{
		Send_Data_String(USART1, str, sizeof(str));
		delay_ms(3000);
		switch(reav_data)
		{

			case 0x01:
				//前进
				set_pwm(200,0,200,0);
				break;
			case 0x02:
				//后退
				set_pwm(0,200,0,300);
				break;
			case 0x03:
				//左转
				set_pwm(000,200,200,0);
				break;
			case 0x04:
				//右转
				set_pwm(200,0,0,200);
				break;
			default:
				//默认停止
				set_pwm(0,0,0,0);
				break;
		}
	}
	
}
*/


/*
//小车循迹
int main()
{

	CAR_Init(8399,999);
	XunJi_Init();
	Car_XunJi_Function();
     
}
*/





/*
//按键控制四种方向
int main()
{
	KEY_Init();
	CAR_Init(8399,999);


	

	while(1)
	{
		if(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0) == 0)
		{
    		//前进
    		set_pwm(666,0,666,0);
    
    	}
    	else if(GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_2) ==0)	
    	{
        	//后退
        	set_pwm(0,666,0,666);
    	}
    	else if(GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_3) ==0)	
    	{
        	//右转
        	set_pwm(333,0,666,0);
    	}
    	else if(GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_4) ==0)	
    	{
        	//左转
        	set_pwm(666,0,333,0);
    	}
	}
}
*/

/*
//按键设置四档转速
int main()
{
	KEY_Init();
	CAR_Init(8399,999);
	

	while(1)
	{
		if(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0) == 0)
		{
    		//停止
    		set_pwm(0,0,0,0);
    
    	}
    	else if(GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_2) ==0)	
    	{
        	//30%速度
        	set_pwm(333,0,333,0);
        	set_pwm(0,333,0,333);
    	}
    	else if(GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_3) ==0)	
    	{
        	//60%速度
        	set_pwm(666,0,666,0);
        	set_pwm(0,666,0,666);
    	}
    	else if(GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_4) ==0)	
    	{
        	//全速
        	set_pwm(999,0,999,0);
        	set_pwm(0,999,0,999);
    	}
	}
}
*/

/*
//使用定时器输出比较单元，输出PWM控制LED的亮灭程度
int main()
{
	//TIM13_PWM 初始化
	TIM13_PWM_Init(83,9999);
	KEY_Init();
	LED_Init();

	 while(1)
	 {
	 	int i;
    	for (i=LED0 ; i<=LED3;i++)
    	{
    		LED_Ctrl(i,LED_ON);
    		my_delay(100);
    	}
    	
		if(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0) ==0)
		{
			//一档
			TIM_SetCompare1(TIM13,0);
		}
		else if(GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_2) ==0)
		{
			//二档
			TIM_SetCompare1(TIM13, 3333);
		}
		else if(GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_3) ==0)
		{
			//三档
			TIM_SetCompare1(TIM13, 6666);
		}
		else if(GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_4) ==0)
		{
			//四档
			TIM_SetCompare1(TIM13, 9999);
		}
	 }
}
*/




/*
//定时器控制蜂鸣器声音大小
int main()
{
	//TIM13_PWM 初始化
	TIM13_PWM_Init(83,9999);
	KEY_Init();
	BEEP_Init();
	BEEP_Ctrl(BEEP_ON);
	
	 while(1)
	 {
		if(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0) ==0)
		{
			//一档
			TIM_SetCompare1(TIM13,0);
		}
		else if(GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_2) ==0)
		{
			//二档
			TIM_SetCompare1(TIM13, 3333);
		}
		else if(GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_3) ==0)
		{
			//三档
			TIM_SetCompare1(TIM13, 6666);
		}
		else if(GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_4) ==0)
		{
			//四档
			TIM_SetCompare1(TIM13, 9999);
		}
	 }
}
*/




/*
//在正常模式下运行流水灯的程序，当产生中断的时候，让蜂鸣器的状态取反!
int main()
{
	//初始化外设
	LED_Init();
	EXTI0_Init();



	BEEP_Init();

	while(1)
  {
  	int i;
	for (i=LED0 ; i<=LED3;i++)
	{
		LED_Ctrl(i,LED_ON);
		my_delay(300);
	}
	
	for (i=LED0 ; i<=LED3;i++)
	{
		LED_Ctrl(i,LED_OFF);
		my_delay(300);
	}
	
	
  }

}

*/



/*
//对应按键控制对应LED灯
int main()
{
	LED_Init();
	KEY_Init();

	while(1)
	{
		if(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0) == 0)
		{
			//按下KEY0
			LED_Ctrl(LED0, LED_ON);
		}
		else
		{
			//弹起KEY0
			LED_Ctrl(LED0, LED_OFF);
		}

		if(GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_2) == 0)
		{
			//按下KEY1
			LED_Ctrl(LED1, LED_ON);
		}
		else
		{
			//弹起KEY1
			LED_Ctrl(LED1, LED_OFF);
		}

		if(GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_3) == 0)
		{
			//按下KEY2
			LED_Ctrl(LED2, LED_ON);
		}
		else
		{
			//弹起KEY2
			LED_Ctrl(LED2, LED_OFF);
		}

		if(GPIO_ReadInputDataBit(GPIOE, GPIO_Pin_4) == 0)
		{
			//按下KEY3
			LED_Ctrl(LED3, LED_ON);
		}
		else
		{
			//弹起KEY3
			LED_Ctrl(LED3, LED_OFF);
		}
	}

}
*/


/*
//KEY0控制LED0
int main()
{
	LED_Init();
	KEY0_Init();

	while(1)
	{
		if(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0) == 0)
		{
			//按下KEY0
			LED_Ctrl(LED0, LED_ON);
		}
		else
		{
			//弹起KEY0
			LED_Ctrl(LED0, LED_OFF);
		}
	}
}
*/






/*
//微秒级的时钟控制流水灯
int main(void)
{
  LED_Init();
  while(1)
  {
  	int i;
	for (i=LED0 ; i<=LED3;i++)
	{
		LED_Ctrl(i,LED_ON);
		delay_us(100);
	}
	
	for (i=LED0 ; i<=LED3;i++)
	{
		LED_Ctrl(i,LED_OFF);
		delay_us(100);
	}
  }
 }
*/

