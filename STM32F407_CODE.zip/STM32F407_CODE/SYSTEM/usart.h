
#ifndef _usart_H_
#define _usart_H_
#include <stdio.h>

void USART1_Init(int Bort);
void USART1_IRQHandler(void);
void Send_Data_String(USART_TypeDef* USARTx,uint8_t * str, int len);
int fputc(int c,FILE * stream);
void USART2_Init(void);
void USART3_Init(void);

void USART3_IRQHandler(void);

void USART2_IRQHandler(void);






#endif









