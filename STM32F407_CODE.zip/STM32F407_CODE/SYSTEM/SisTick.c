
#include <stm32f4xx.h>
#include "SisTick.h"


int cnt = 0; //记录需要产生中断次数
void delay_ms(int n) //n:表示要延时n毫秒
	{
		cnt = n;
		
		//将SysTick配置为，每隔1ms产生一次中断
		//a、将 Control and Status 寄存器中的 bit0 设置为0
		rSysTickCTL &= ~(0x01 << 0); 
		//b、将 Control and Status 寄存器中的 bit2 设置为1.
		rSysTickCTL |= (0x01 << 2);	
		//c、将 Control and Status 寄存器中的 bit1 设置为1.
		rSysTickCTL |= (0x01 << 1);
		//d、设置N值 
			/*
			选择SysTick的时钟源为内核时钟: 168M 
			计数器递减一次的时间t : 1 / 168M  s
			让SysTick每隔1ms产生一次中断: 
			(N + 1) * t = 1ms 
			=> (N + 1) = 168000
			=> N = 167999
			*/
			rSysTickRELOAD = 167999;
			rSysTickCURVAL = 0;
			//e、将 Control and Status 寄存器中的 bit0 设置为1.
			rSysTickCTL |= (0x01 << 0);
			
			//等待n毫秒时间过去
			while( cnt > 0 );
				
			//关闭SysTick
			rSysTickCTL &= ~(0x01 << 0); 
	}


void delay_us(int n) //n:表示要延时n微秒
	{
		cnt = n;
		
		//将SysTick配置为，每隔1us产生一次中断
		//a、将 Control and Status 寄存器中的 bit0 设置为0
		rSysTickCTL &= ~(0x01 << 0); //禁止SisTick
		//b、将 Control and Status 寄存器中的 bit2 设置为1.
		rSysTickCTL |= (0x01 << 2);	//选择时钟168M
		//c、将 Control and Status 寄存器中的 bit1 设置为1.
		rSysTickCTL |= (0x01 << 1);//使能SisTick中断
		//d、设置N值 
			/*
			选择SysTick的时钟源为内核时钟: 168M 
			计数器递减一次的时间t : 1 / 168M  s
			让SysTick每隔1us产生一次中断: 
			(N + 1) * t = 1us 
			=> (N + 1) = 168
			=> N = 167
			*/
		rSysTickRELOAD = 167;
		rSysTickCURVAL = 0;
			//e、将 Control and Status 寄存器中的 bit0 设置为1.
		rSysTickCTL |= (0x01 << 0);
			
			//等待n微秒时间过去
		while( cnt > 0 );
				
			//关闭SysTick
		rSysTickCTL &= ~(0x01 << 0); 
	}



void SysTick_Handler(void)
	{
		cnt--;
	}





