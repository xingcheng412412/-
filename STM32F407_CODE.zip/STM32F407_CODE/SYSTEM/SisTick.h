
#ifndef _SisTick_H_
#define _SisTick_H_

#define rSysTickCTL *((volatile unsigned long *)0xE000E010)
#define rSysTickRELOAD *((volatile unsigned long *)0xE000E014)
#define rSysTickCURVAL *((volatile unsigned long *)0xE000E018)
void delay_ms(int n);
void SysTick_Handler(void);



#endif

