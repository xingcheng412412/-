#ifndef _KEY_H_
#define _KEY_H_

void KEY0_Init(void);

#define KEY0 0
#define KEY1 1
#define KEY2 2
#define KEY3 3


void KEY_Init(void);


#endif













