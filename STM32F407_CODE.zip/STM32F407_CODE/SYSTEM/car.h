
#ifndef _car_H_
#define _car_H_


void CAR_Init(uint16_t psc,uint32_t N);
void set_pwm(uint32_t A_1A,uint32_t A_1B,uint32_t B_1A,uint32_t B_1B);
void XunJi_Init(void);
void Car_XunJi_Function(void);




#endif


