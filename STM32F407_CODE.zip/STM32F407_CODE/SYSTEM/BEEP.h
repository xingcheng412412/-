
#ifndef _BEEP_H_
#define _BEEP_H_


#define BEEP_ON 1
#define BEEP_OFF 0

void BEEP_Init(void);
void BEEP_Ctrl(int sta);





#endif





