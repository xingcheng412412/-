#include <stm32f4xx.h>
#include "exti.h"
#include "led.h"



/*
void BEEP_Init(void)
{
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOF, ENABLE);
	//a、使能GPIO分组的时钟
		RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
		//b、初始化配置GPIO的引脚功能
		GPIO_InitTypeDef GPIO_InitStruct;
		GPIO_InitStruct.GPIO_Pin = GPIO_Pin_8;
		GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT; //输出模式
		GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_NOPULL;
		GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
		GPIO_Init(GPIOF, &GPIO_InitStruct );
		BEEP_Ctrl(BEEP_OFF);
}



void BEEP_Ctrl(int b)
{

	if(b == BEEP_ON)
	{
		GPIO_WriteBit( GPIOF,  GPIO_Pin_8,  (BitAction)1);
	}
	else 
	{
		GPIO_WriteBit( GPIOF,  GPIO_Pin_8,  (BitAction)0);
	}
}
*/

/*
	EXTI0_Init :初始化中断0
		KEY0>PA0>EXTI0
*/

void EXTI0_Init(void)
{
	//1.GPIO控制器的配置
		//a、使能GPIO分组的时钟
		RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
		//b、初始化配置GPIO的引脚功能
		GPIO_InitTypeDef GPIO_InitStruct;
		GPIO_InitStruct.GPIO_Pin = GPIO_Pin_0;
		GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN; //输入模式
		GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_NOPULL;
		GPIO_Init(GPIOF, &GPIO_InitStruct );
		
	//2.配置SYSCFG选择器
		RCC_AHB2PeriphClockCmd(RCC_APB2Periph_SYSCFG, ENABLE);
		SYSCFG_EXTILineConfig(EXTI_PortSourceGPIOA, EXTI_PinSource0);

	//3.EXTI外部中断控制器
		RCC_AHB2PeriphClockCmd(RCC_APB2Periph_EXTIT,ENABLE);

		EXTI_InitTypeDef  EXTI_InitStruct;
		EXTI_InitStruct.EXTI_Line = EXTI_Line0;
		EXTI_InitStruct.EXTI_Mode = EXTI_Mode_Interrupt;
		EXTI_InitStruct.EXTI_Trigger = EXTI_Trigger_Falling;
		EXTI_InitStruct.EXTI_LineCmd = ENABLE;
		EXTI_Init(&EXTI_InitStruct );
	//4.中断控制器的配置
		NVIC_InitTypeDef  NVIC_InitStruct;
		NVIC_InitStruct.NVIC_IRQChannel = EXTI0_IRQn;
		NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 1;
		NVIC_InitStruct.NVIC_IRQChannelSubPriority = 1;
		NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
		NVIC_Init(&NVIC_InitStruct );
}

//中断处理函数

int sta = LED_OFF ;
int _Beep=BEEP_OFF;

void EXTI0_IRQHandler(void)
{		
		
	
	//判断是否由EXTI_Line0引脚产生了中断
		if(EXTI_GetITStatus(EXTI_Line0) == SET)
		{
			int i;
			sta = !sta;
			for(i=LED0;i<=LED3;i++)
			{
				LED_Ctrl(i,sta);
			}		
			
			if(GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0) == 0)
		{
			_Beep = !_Beep;
			//按下KEY0
			BEEP_Ctrl(_Beep);
		}		
			//清除中断挂起标志位 
			EXTI_ClearITPendingBit( EXTI_Line0);
		}
}





