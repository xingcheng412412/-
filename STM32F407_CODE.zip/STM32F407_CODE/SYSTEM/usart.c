
#include <stm32f4xx.h>
#include <stdio.h>
#include "usart.h"
#include "car.h"
#include "BEEP.h"

void USART1_Init(int Bort)
{
	GPIO_InitTypeDef GPIO_InitStruct;
	USART_InitTypeDef USART_InitStruct;
	NVIC_InitTypeDef NVIC_InitStruct;
	//1、GPIO控制器的配置
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);

	
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_9|GPIO_Pin_10; 
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF; //复用
	GPIO_InitStruct.GPIO_OType = GPIO_OType_PP; //推挽 
	GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
	
	GPIO_Init(GPIOA, &GPIO_InitStruct );
	
	GPIO_PinAFConfig(GPIOA, GPIO_PinSource9, GPIO_AF_USART1);
	GPIO_PinAFConfig(GPIOA, GPIO_PinSource10,GPIO_AF_USART1);

	//2、初始化配置USART控制器
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);

	
	USART_InitStruct.USART_BaudRate = Bort;
	USART_InitStruct.USART_WordLength = USART_WordLength_8b;
	USART_InitStruct.USART_StopBits = USART_StopBits_1;
	USART_InitStruct.USART_Parity = USART_Parity_No;
	USART_InitStruct.USART_Mode = USART_Mode_Rx|USART_Mode_Tx;
	USART_InitStruct.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	
	USART_Init(USART1, &USART_InitStruct);

	//3、串口中断的配置
	USART_ITConfig(USART1,USART_IT_RXNE, ENABLE);

	
	NVIC_InitStruct.NVIC_IRQChannel = USART1_IRQn;
	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 2;
	NVIC_InitStruct.NVIC_IRQChannelSubPriority = 2;
	NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
	
	NVIC_Init(&NVIC_InitStruct);
	NVIC_EnableIRQ(USART1_IRQn);

	//开启串口
	USART_Cmd(USART1, ENABLE);
	
	
}


//5、设置中断函数进行串口数据的接收
uint16_t reav_data = 0x00;//保存接收到的数据


unsigned char u1_recv[256] = {0}; //保存接收到的数据
int u1_recv_count = 0; //记录接收到的字节数				
int u1_recv_flag = 0;  //0 - 接收未完成	，1 - 接收完成 
int smoke;

void USART1_IRQHandler(void)
{
	unsigned char ch;
	if(USART_GetITStatus(USART1,  USART_IT_RXNE) == SET)
	{
		ch = USART_ReceiveData(USART1);
		u1_recv[u1_recv_count]=ch;
		u1_recv_count++;
		if(u1_recv[1]==0x86 && u1_recv_count==9)
			{
			smoke  = u1_recv[2]<<8 | u1_recv[3];
			smoke = smoke/100;
			u1_recv_count=0;
			u1_recv_flag=1;
			
		}
		USART_ClearITPendingBit(USART1,USART_IT_RXNE);
		//接收数据 
		//reav_data = USART_ReceiveData(USART1);
		
		//清除中断挂起标志位
		//USART_ClearITPendingBit(USART1,  USART_IT_RXNE);
	}
}




void USART2_Init(void)
{	
	GPIO_InitTypeDef GPIO_InitStruct;
	USART_InitTypeDef USART_InitStruct;
	NVIC_InitTypeDef NVIC_InitStruct;
	//1、GPIO控制器的配置
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);

	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_2|GPIO_Pin_3;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF;//复用
	GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;//推挽输出
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;

	GPIO_Init(GPIOA, &GPIO_InitStruct);

	GPIO_PinAFConfig(GPIOA, GPIO_PinSource2, GPIO_AF_USART2);
	GPIO_PinAFConfig(GPIOA, GPIO_PinSource3, GPIO_AF_USART2);

	//2、初始化配置USART控制器
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);

	USART_InitStruct.USART_BaudRate = 9600;
	USART_InitStruct.USART_WordLength = USART_WordLength_8b;
	USART_InitStruct.USART_StopBits = USART_StopBits_1;
	USART_InitStruct.USART_Parity = USART_Parity_No;
	USART_InitStruct.USART_Mode = USART_Mode_Rx|USART_Mode_Tx;
	USART_InitStruct.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	
	USART_Init(USART2, &USART_InitStruct);

	//3、串口中断的配置
	USART_ITConfig(USART2,USART_IT_RXNE, ENABLE);

	
	NVIC_InitStruct.NVIC_IRQChannel = USART2_IRQn;
	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 3;
	NVIC_InitStruct.NVIC_IRQChannelSubPriority = 3;
	NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
	
	NVIC_Init(&NVIC_InitStruct);
	NVIC_EnableIRQ(USART2_IRQn);

	//开启串口
	USART_Cmd(USART2, ENABLE);
}



//蓝牙模块接收数据
void USART2_IRQHandler(void)
{
	if(USART_GetITStatus(USART2, USART_IT_RXNE) == SET)
	{

		reav_data = USART_ReceiveData(USART2);
		switch (reav_data)
		{
    		case 0x01:
    			//前进
    			set_pwm(888,0,888,0);
    			break;
    		case 0x02:
    			//后退
    			set_pwm(0,888,0,888);
    			break;
    		case 0x03:
    			//左转
    			set_pwm(000,888,888,0);
    			break;
    		case 0x04:
    			//右转
    			set_pwm(888,0,0,888);
    			break;
			  case 0x05:
    			//停止
    			set_pwm(0,0,0,0);
    			break;
			  case 0x06:
				  Car_XunJi_Function();
				  break;
    	  default:
    			//默认停止
    			set_pwm(0,0,0,0);
    			break;	
		}

		USART_ClearITPendingBit(USART2, USART_IT_RXNE);
	

	}
}

/*
	USART3_TX--PB10
	USART3_RX--PB11
	USART3--APB1
	GPIOB--AHB1
*/
void USART3_Init(void)
{	
	GPIO_InitTypeDef GPIO_InitStruct;
	USART_InitTypeDef USART_InitStruct;
	NVIC_InitTypeDef NVIC_InitStruct;
	//1、GPIO控制器的配置
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);

	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_10|GPIO_Pin_11;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF;//复用
	GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;//推挽输出
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;

	GPIO_Init(GPIOB, &GPIO_InitStruct);

	GPIO_PinAFConfig(GPIOB, GPIO_PinSource10, GPIO_AF_USART3);
	GPIO_PinAFConfig(GPIOB, GPIO_PinSource11, GPIO_AF_USART3);

	//2、初始化配置USART控制器
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE);

	USART_InitStruct.USART_BaudRate = 9600;
	USART_InitStruct.USART_WordLength = USART_WordLength_8b;
	USART_InitStruct.USART_StopBits = USART_StopBits_1;
	USART_InitStruct.USART_Parity = USART_Parity_No;
	USART_InitStruct.USART_Mode = USART_Mode_Rx|USART_Mode_Tx;
	USART_InitStruct.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	
	USART_Init(USART3, &USART_InitStruct);

	//3、串口中断的配置
	USART_ITConfig(USART3,USART_IT_RXNE, ENABLE);

	
	NVIC_InitStruct.NVIC_IRQChannel = USART3_IRQn;
	NVIC_InitStruct.NVIC_IRQChannelPreemptionPriority = 2;
	NVIC_InitStruct.NVIC_IRQChannelSubPriority = 2;
	NVIC_InitStruct.NVIC_IRQChannelCmd = ENABLE;
	
	NVIC_Init(&NVIC_InitStruct);
	NVIC_EnableIRQ(USART3_IRQn);

	//开启串口
	USART_Cmd(USART3, ENABLE);
}





unsigned char u3_recv[256] = {0}; //保存接收到的数据
int u3_recv_count = 0; //记录接收到的字节数				
int u3_recv_flag = 0;  //0 - 接收未完成	，1 - 接收完成 
int temp,pre,hum,height,light;

//GY_39接收数据
void USART3_IRQHandler(void)
{
	unsigned char ch;
	if(USART_GetITStatus(USART3,USART_IT_RXNE) == SET)
	{
		
		ch = USART_ReceiveData(USART3);		
		u3_recv[u3_recv_count] = ch;
		u3_recv_count++;

		//光照强度
		if(u3_recv[2]==0x15 && u3_recv_count==9)
		{
			light = u3_recv[4]<<24 | u3_recv[5]<<16 | u3_recv[6]<<8 | u3_recv[7];
			light = light/10;
			u3_recv_count = 0;
			u3_recv_flag = 1;
		}


		//温度、气压、湿度、海拔
		else if(u3_recv[2]==0x45 &&  u3_recv_count==15)
		{
			temp = u3_recv[4]<<8 | u3_recv[5];
			pre = u3_recv[6]<<24 | u3_recv[7]<<16 | u3_recv[8]<<8 | u3_recv[9];
			hum = u3_recv[10]<<8 | u3_recv[11];
			height = u3_recv[12]<<8 | u3_recv[13];
			
			temp = temp/100;
			pre = pre/100000;
			hum = hum/100;
			height = height/1000;
			u3_recv_count = 0;
			u3_recv_flag = 1;
		}		
				
		USART_ClearITPendingBit(USART3,USART_IT_RXNE);
	}
}


void Send_Data_String(USART_TypeDef* USARTx, uint8_t * str, int len)
{
	int i;
	for(i = 0;i<len;i++)
	{
		//等待发送数据寄存器为空
		while(USART_GetFlagStatus(USARTx, USART_FLAG_TXE) == RESET);
		//发送一个字节的数据
		USART_SendData(USARTx, str[i]);
		
			
	}
}


int fputc(int c,FILE * stream)
{
		//等待发送数据寄存器为空
		while(USART_GetFlagStatus(USART2, USART_FLAG_TXE) == RESET);
		//发送一个字节的数据
		USART_SendData(USART2, (uint16_t)c);
	
		return 0;
}




