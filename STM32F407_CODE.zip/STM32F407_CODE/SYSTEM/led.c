#include <STM32F4xx.h>
#include <stdint.h>
#include "led.h"


void my_delay(int n)
{
	while(n--)
	{
	int i;
	for(i = 0;i<=10000;i++)
	{
		;
	}
	}
}


//初始化，LED0:PF9，LED1:PF10，FSMC_D10:PE13,FSMC_D11:PE14,推挽输出，输出速率
void LED_Init(void)
{

	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOF, ENABLE);
    RCC_AHB1PeriphClockCmd( RCC_AHB1Periph_GPIOE, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStruct;
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_9|GPIO_Pin_10; 
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT; //输出
	GPIO_InitStruct.GPIO_OType = GPIO_OType_PP; //推挽 
	GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOF, &GPIO_InitStruct );
					
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_13|GPIO_Pin_14;
	GPIO_Init(GPIOE, &GPIO_InitStruct );
	
	int i; 
	for(i=LED0 ; i<=LED3 ; i++)
	{
		LED_Ctrl(i,LED_OFF); 
	}
}	


void LED_Ctrl(int led_num, int sta)
{
	GPIO_TypeDef* GPIOx ; //记录led_num的GPIO分组 
	uint16_t GPIO_Pin; //记录led_num的编号 

	if(led_num == LED0)
	{
		GPIOx = GPIOF;
		GPIO_Pin = GPIO_Pin_9;
	}
	else if(led_num == LED1)
	{
		GPIOx = GPIOF;
		GPIO_Pin = GPIO_Pin_10;
	}
	else if(led_num == LED2)
	{
		GPIOx = GPIOE;
		GPIO_Pin = GPIO_Pin_13;
	}
	else if(led_num == LED3)
	{
		GPIOx = GPIOE;
		GPIO_Pin = GPIO_Pin_14;
	}

	if(sta == LED_ON)
	{
		GPIO_WriteBit( GPIOx,  GPIO_Pin,  (BitAction)0);
	}
	else 
	{
		GPIO_WriteBit( GPIOx,  GPIO_Pin,  (BitAction)1);
	}

}







