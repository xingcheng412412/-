
#include <stm32f4xx.h>
#include "BEEP.h"

void BEEP_Init(void)
{
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOF, ENABLE);
	//a、使能GPIO分组的时钟
		RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
		//b、初始化配置GPIO的引脚功能
		GPIO_InitTypeDef GPIO_InitStruct;
		GPIO_InitStruct.GPIO_Pin = GPIO_Pin_8;
		GPIO_InitStruct.GPIO_Mode = GPIO_Mode_OUT; //输出模式
		GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_NOPULL;
		GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
		GPIO_Init(GPIOF, &GPIO_InitStruct );
		BEEP_Ctrl(BEEP_OFF);
}



void BEEP_Ctrl(int b)
{

	if(b == BEEP_ON)
	{
		GPIO_WriteBit( GPIOF,  GPIO_Pin_8,  (BitAction)1);
	}
	else 
	{
		GPIO_WriteBit( GPIOF,  GPIO_Pin_8,  (BitAction)0);
	}
}







