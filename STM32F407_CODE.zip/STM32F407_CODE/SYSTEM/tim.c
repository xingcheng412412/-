
#include <stm32f4xx.h>
#include "tim.h"

/*
	TIM_13_PWM_Init:初始化定时器13输出PWM
	PF8 -> TIM13_CH1
*/

void TIM13_PWM_Init(uint16_t psc,uint16_t N)
{
	GPIO_InitTypeDef GPIO_InitStruct;
	TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStruct;
	TIM_OCInitTypeDef TIM_OCInitStruct;
	//1.GPIO控制器配置
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOF, ENABLE);

	GPIO_InitStruct.GPIO_Pin =GPIO_Pin_8;
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF;//复用
	GPIO_InitStruct.GPIO_OType = GPIO_OType_PP;//推挽输出
	GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOF,&GPIO_InitStruct);

	GPIO_PinAFConfig(GPIOF, GPIO_PinSource8,GPIO_AF_TIM13);

	//2.初始化时基单元
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM13, ENABLE);

	TIM_TimeBaseInitStruct.TIM_ClockDivision = TIM_CKD_DIV1;
	TIM_TimeBaseInitStruct.TIM_CounterMode =TIM_CounterMode_Up;
	TIM_TimeBaseInitStruct.TIM_Period = N;//N值
	TIM_TimeBaseInitStruct.TIM_Prescaler =psc;//预分频
	//TIM_TimeBaseInit.TIM_RepetitionCounter
	TIM_TimeBaseInit(TIM13,&TIM_TimeBaseInitStruct);

	//3.配置定时器的输出通道
	TIM_OCInitStruct.TIM_OCMode = TIM_OCMode_PWM1;//CNT<CCR 有效电平
	TIM_OCInitStruct.TIM_OCPolarity = TIM_OCPolarity_High;//高电平有效
	TIM_OCInitStruct.TIM_OutputState = TIM_OutputState_Enable;
	TIM_OCInitStruct.TIM_Pulse = 0;//CCR比较值
	//TIM_OCInitStruct.TIM_OutputNState
	//TIM_OCInitStruct.TIM_OCNPolarity
	//TIM_OCInitStruct.TIM_OCNIdleState
	//TIM_OCInitStruct.TIM_OCTdleState
	TIM_OC1Init(TIM13,&TIM_OCInitStruct);

	TIM_OC1PreloadConfig(TIM13,TIM_OCPreload_Enable);
	TIM_ARRPreloadConfig(TIM13, ENABLE);

	//4.开启定时器
	TIM_Cmd(TIM13, ENABLE);
}








