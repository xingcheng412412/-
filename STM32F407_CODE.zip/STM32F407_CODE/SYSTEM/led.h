#ifndef _led_H_
#define _led_H_

#define LED_ON 0
#define LED_OFF 1


#define LED0 0
#define LED1 1
#define LED2 2
#define LED3 3


void my_delay(int n);
void LED_Init(void);
void LED_Ctrl(int led_num, int sta);

#endif

