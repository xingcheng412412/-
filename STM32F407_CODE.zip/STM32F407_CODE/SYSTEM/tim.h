
#ifndef _tim_H_
#define _tim_H_


void TIM13_PWM_Init(uint16_t psc, uint16_t N);







#endif


