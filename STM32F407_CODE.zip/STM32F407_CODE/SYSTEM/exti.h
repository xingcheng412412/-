#ifndef _exit_H_
#define _exti_H_

#define BEEP_ON 1
#define BEEP_OFF 0

void EXTI0_Init(void);
void EXTI0_IRQHandler(void);
void BEEP_Init(void);
void BEEP_Ctrl(int sta);



#endif
