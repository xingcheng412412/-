
#include <stm32f4xx.h>
#include "Serial.h"
#include "car.h"

void Serial_Port_Init(void)
{
	//1、GPIO控制器的配置
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);

	GPIO_InitTypeDef GPIO_InitStruct;
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_2|GPIO_Pin_3; 
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF; //复用
	GPIO_InitStruct.GPIO_OType = GPIO_OType_PP; //推挽 
	GPIO_InitStruct.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
	
	GPIO_Init(GPIOA, &GPIO_InitStruct );
	
	GPIO_PinAFConfig(GPIOA, GPIO_PinSource_2, GPIO_AF_USART2);
	GPIO_PinAFConfig(GPIOA, GPIO_PinSource_3,GPIO_AF_USART2);

	//2、初始化配置USART控制器
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);

	USART_InitTypeDef USART_InitStruct;
	USART_InitStruct.USART_BaudRate = 9600;
	USART_InitStruct.USART_WordLength = USART_WordLength_8b;
	USART_InitStruct.USART_StopBits = USART_StopBits_1;
	USART_InitStruct.USART_Parity = USART_Parity_No;
	USART_InitStruct.USART_Mode = USART_Mode_Rx;
	USART_InitStruct.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	
	USART_Init(USART2, USART_InitStruct);

	//3、串口中断的配置
	USART_ITConfig(USART2,USART_IT_RXNE, ENABLE);

	NVIC_InitTypeDef NVIC_Initstruct;
	NVIC_Initstruct.NVIC_IRQChannel = EXTI9_5_IRQn;
	NVIC_Initstruct.NVIC_IRQChannelPreemptionPriority = 1;
	NVIC_Initstruct.NVIC_IRQChannelSubPriority = 1;
	NVIC_Initstruct.NVIC_IRQChannelCmd = ENABLE;
	
	NVIC_Init(&NVIC_InitStruct);

	//开启串口
	USART_Cmd(USART2, ENABLE);
	
	
}


//5、设置中断函数进行串口数据的接收
uint16_t reav_data = 0;//保存接收到的数据

void USART2_IRQHandler(void)
{	
	if(USART_GetITStatus(USART2, USART_IT_RXNE) == SET);
	{
		reav_data = USART_ReceiveData(USART2);
		switch(reav_data)
		{
			case 1:
				//前进
				set_pwm(300,0,300,0);
				break;
			case 2:
				//后退
				set_pwm(0,300,0,300);
				break;
			case 3:
				//左转
				set_pwm(0,0,300,0);
				break;
			case 4:
				//右转
				set_pwm(300,0,0,0);
				break;
		}
		USART_ClearITPendingBit(USART1, USART_IT_RXNE);
		
	}
	
}












